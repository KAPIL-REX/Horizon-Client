/**
 * Horizon Client - Main Entry Point
 * Bootstrap and initialize all core systems.
 */

import { MainMenu } from './menu/MainMenu.js';
import { EventBus } from './core/EventBus.js';
import { ModuleManager } from './core/ModuleManager.js';
import { ConfigManager } from './core/ConfigManager.js';
import { KeybindManager } from './core/KeybindManager.js';
import { NotificationManager } from './core/NotificationManager.js';

class HorizonClient {
    constructor() {
        console.log('%c[Horizon Client] Initializing...', 'color: #00d4ff; font-weight: bold;');

        // Core systems
        this.eventBus = new EventBus();
        this.config = new ConfigManager();
        this.notifications = new NotificationManager();
        this.keybinds = new KeybindManager(this.eventBus);
        this.modules = new ModuleManager(this.eventBus, this.config, this.keybinds, this.notifications);

        // UI
        this.menu = new MainMenu(this);

        this.init();
    }

    async init() {
        try {
            // Load saved configuration
            await this.config.load();

            // Initialize modules (will be expanded later)
            this.modules.init();

            // Render main menu
            this.menu.render();

            console.log('%c[Horizon Client] Ready.', 'color: #00ff9d; font-weight: bold;');
            this.notifications.info('Horizon Client loaded successfully.');
        } catch (err) {
            console.error('[Horizon] Initialization error:', err);
        }
    }
}

// Global instance
window.Horizon = new HorizonClient();
