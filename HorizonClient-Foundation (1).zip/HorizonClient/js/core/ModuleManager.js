/**
 * Horizon Client - Module Manager
 * Registers, enables, disables, and ticks all modules.
 */

export class ModuleManager {
    constructor(eventBus, config, keybinds, notifications) {
        this.eventBus = eventBus;
        this.config = config;
        this.keybinds = keybinds;
        this.notifications = notifications;

        this.modules = new Map(); // name -> module instance
        this.enabled = new Set();

        // Listen for keybind events
        this.eventBus.on('keybind', (bind) => {
            if (bind.action === 'toggle') {
                this.toggle(bind.module);
            }
        });
    }

    /**
     * Register a module instance
     */
    register(module) {
        if (this.modules.has(module.name)) {
            console.warn(`[Modules] Module "${module.name}" is already registered.`);
            return;
        }

        this.modules.set(module.name, module);

        // Restore saved state
        const saved = this.config.getModuleConfig(module.name);
        if (saved.enabled) {
            this.enable(module.name, true); // silent
        }

        // Register default keybind if provided
        if (module.defaultKey !== undefined && module.defaultKey !== null) {
            this.keybinds.register(module.name, module.defaultKey);
        }

        console.log(`[Modules] Registered: ${module.name} [${module.category}]`);
    }

    init() {
        // In a full implementation, modules would be imported and registered here.
        // Example:
        // import { KillAura } from '../modules/combat/KillAura.js';
        // this.register(new KillAura(this.eventBus));

        console.log(`[Modules] Manager initialized. ${this.modules.size} modules loaded.`);
    }

    enable(name, silent = false) {
        const mod = this.modules.get(name);
        if (!mod || this.enabled.has(name)) return;

        mod.onEnable?.();
        this.enabled.add(name);
        this.config.setModuleConfig(name, { enabled: true });

        if (!silent) {
            this.notifications.success(`${name} enabled`);
            this.eventBus.emit('module-toggled', { name, enabled: true });
        }
    }

    disable(name, silent = false) {
        const mod = this.modules.get(name);
        if (!mod || !this.enabled.has(name)) return;

        mod.onDisable?.();
        this.enabled.delete(name);
        this.config.setModuleConfig(name, { enabled: false });

        if (!silent) {
            this.notifications.info(`${name} disabled`);
            this.eventBus.emit('module-toggled', { name, enabled: false });
        }
    }

    toggle(name) {
        if (this.enabled.has(name)) {
            this.disable(name);
        } else {
            this.enable(name);
        }
    }

    isEnabled(name) {
        return this.enabled.has(name);
    }

    getModulesByCategory(category) {
        const result = [];
        for (const mod of this.modules.values()) {
            if (mod.category === category) result.push(mod);
        }
        return result;
    }

    getAll() {
        return Array.from(this.modules.values());
    }

    /**
     * Called every client tick (to be hooked into the game loop later)
     */
    onTick() {
        for (const name of this.enabled) {
            const mod = this.modules.get(name);
            mod?.onTick?.();
        }
    }
}
