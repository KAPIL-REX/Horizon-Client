/**
 * Horizon Client - Keybind Manager
 * Handles keybind registration, conflict detection, and input.
 */

export class KeybindManager {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.binds = new Map(); // keyCode -> { module, action }
        this.listening = false;
        this.pendingBind = null;

        window.addEventListener('keydown', (e) => this.onKeyDown(e));
        window.addEventListener('keyup', (e) => this.onKeyUp(e));
    }

    /**
     * Register a keybind for a module
     * @param {string} moduleName 
     * @param {number} keyCode 
     * @param {string} action - usually 'toggle'
     */
    register(moduleName, keyCode, action = 'toggle') {
        // Simple conflict check
        if (this.binds.has(keyCode)) {
            const existing = this.binds.get(keyCode);
            console.warn(`[Keybinds] Conflict: Key ${keyCode} already bound to ${existing.module}`);
        }

        this.binds.set(keyCode, { module: moduleName, action });
        console.log(`[Keybinds] Registered ${moduleName} -> key ${keyCode}`);
    }

    unregister(moduleName) {
        for (const [key, value] of this.binds.entries()) {
            if (value.module === moduleName) {
                this.binds.delete(key);
            }
        }
    }

    onKeyDown(e) {
        // Ignore if typing in an input
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

        if (this.listening && this.pendingBind) {
            this.register(this.pendingBind.module, e.keyCode, this.pendingBind.action);
            this.listening = false;
            this.pendingBind = null;
            this.eventBus.emit('keybind-updated');
            e.preventDefault();
            return;
        }

        const bind = this.binds.get(e.keyCode);
        if (bind) {
            this.eventBus.emit('keybind', bind);
            e.preventDefault();
        }
    }

    onKeyUp(e) {
        // Reserved for hold-style keybinds in the future
    }

    /**
     * Start listening for a new keybind
     */
    listenForBind(moduleName, action = 'toggle') {
        this.listening = true;
        this.pendingBind = { module: moduleName, action };
        console.log(`[Keybinds] Listening for new bind for ${moduleName}...`);
    }

    getBind(moduleName) {
        for (const [key, value] of this.binds.entries()) {
            if (value.module === moduleName) return key;
        }
        return null;
    }
}
