/**
 * Horizon Client - Base Module Class
 * All modules should extend this class.
 */

export class BaseModule {
    constructor(name, category, description = '') {
        this.name = name;
        this.category = category; // COMBAT, MOVEMENT, RENDER, PLAYER, WORLD, CLIENT, MISC
        this.description = description;
        this.enabled = false;
        this.defaultKey = null; // keyCode
        this.settings = {};
    }

    /** Called when the module is enabled */
    onEnable() {
        this.enabled = true;
    }

    /** Called when the module is disabled */
    onDisable() {
        this.enabled = false;
    }

    /** Called every client tick while enabled */
    onTick() {}

    /** Optional render hook */
    onRender() {}

    /** Helper to add a setting */
    addSetting(key, defaultValue, options = {}) {
        this.settings[key] = {
            value: defaultValue,
            ...options
        };
    }

    getSetting(key) {
        return this.settings[key]?.value;
    }

    setSetting(key, value) {
        if (this.settings[key]) {
            this.settings[key].value = value;
        }
    }
}
