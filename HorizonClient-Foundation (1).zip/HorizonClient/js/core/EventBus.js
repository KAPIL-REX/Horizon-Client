/**
 * Horizon Client - Event Bus
 * Simple publish/subscribe system for module communication.
 */

export class EventBus {
    constructor() {
        this.listeners = new Map();
    }

    /**
     * Subscribe to an event
     * @param {string} event 
     * @param {Function} callback 
     * @returns {Function} unsubscribe function
     */
    on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, new Set());
        }
        this.listeners.get(event).add(callback);

        // Return unsubscribe function
        return () => this.off(event, callback);
    }

    /**
     * Subscribe once
     */
    once(event, callback) {
        const wrapper = (...args) => {
            this.off(event, wrapper);
            callback(...args);
        };
        this.on(event, wrapper);
    }

    /**
     * Unsubscribe
     */
    off(event, callback) {
        const set = this.listeners.get(event);
        if (set) {
            set.delete(callback);
        }
    }

    /**
     * Emit an event
     */
    emit(event, ...args) {
        const set = this.listeners.get(event);
        if (set) {
            for (const callback of set) {
                try {
                    callback(...args);
                } catch (err) {
                    console.error(`[EventBus] Error in listener for "${event}":`, err);
                }
            }
        }
    }

    /**
     * Clear all listeners for an event (or all events)
     */
    clear(event = null) {
        if (event) {
            this.listeners.delete(event);
        } else {
            this.listeners.clear();
        }
    }
}
