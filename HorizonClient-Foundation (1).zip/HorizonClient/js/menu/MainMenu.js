/**
 * Horizon Client - Main Menu Controller
 * Handles the Badlion-style title screen interactions.
 */

export class MainMenu {
    constructor(client) {
        this.client = client;
        this.container = document.getElementById('main-menu');
    }

    render() {
        const buttons = document.querySelectorAll('.menu-btn');

        buttons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleAction(action);
            });
        });

        // Optional: subtle ambient particle effect can be added here later
        console.log('[Horizon] Main menu rendered.');
    }

    handleAction(action) {
        switch (action) {
            case 'singleplayer':
                this.client.notifications.info('Singleplayer is not yet connected to a world backend.');
                console.log('[Horizon] Singleplayer requested');
                // Future: transition to world selection / Eaglercraft singleplayer
                break;

            case 'multiplayer':
                this.client.notifications.info('Multiplayer server list coming soon.');
                console.log('[Horizon] Multiplayer requested');
                break;

            case 'horizon-options':
                this.client.notifications.info('Horizon Options panel will open here.');
                console.log('[Horizon] Horizon Options requested');
                // Future: open client-specific settings
                break;

            case 'cosmetics':
                this.client.notifications.info('Cosmetics system placeholder.');
                console.log('[Horizon] Cosmetics requested');
                break;

            case 'options':
                this.client.notifications.info('Minecraft Options will open here.');
                console.log('[Horizon] Options requested');
                break;

            case 'quit':
                if (confirm('Are you sure you want to quit Horizon Client?')) {
                    window.close();
                    // Fallback for browsers that block window.close()
                    document.body.innerHTML = `
                        <div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#060a12;color:#8ba3c0;font-family:system-ui;">
                            <div style="text-align:center;">
                                <h2 style="color:#e0e6f0;margin-bottom:0.5rem;">Horizon Client</h2>
                                <p>You may now close this tab.</p>
                            </div>
                        </div>`;
                }
                break;

            default:
                console.warn('[Horizon] Unknown menu action:', action);
        }
    }

    hide() {
        if (this.container) {
            this.container.style.display = 'none';
        }
    }

    show() {
        if (this.container) {
            this.container.style.display = 'flex';
        }
    }
}
