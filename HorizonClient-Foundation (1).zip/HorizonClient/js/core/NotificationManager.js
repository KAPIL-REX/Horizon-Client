/**
 * Horizon Client - Notification Manager
 * Simple toast-style notifications.
 */

export class NotificationManager {
    constructor() {
        this.container = null;
        this.queue = [];
        this.createContainer();
    }

    createContainer() {
        this.container = document.createElement('div');
        this.container.id = 'horizon-notifications';
        this.container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
        `;
        document.body.appendChild(this.container);
    }

    show(message, type = 'info', duration = 3200) {
        const toast = document.createElement('div');
        
        const colors = {
            info:    { bg: 'rgba(0, 40, 80, 0.92)', border: '#00a0e0' },
            success: { bg: 'rgba(0, 50, 40, 0.92)', border: '#00d4a0' },
            warn:    { bg: 'rgba(60, 40, 0, 0.92)',  border: '#e0a000' },
            error:   { bg: 'rgba(60, 10, 10, 0.92)', border: '#e04040' }
        };

        const style = colors[type] || colors.info;

        toast.style.cssText = `
            background: ${style.bg};
            border-left: 3px solid ${style.border};
            color: #e8f0ff;
            padding: 12px 18px;
            border-radius: 6px;
            font-size: 0.9rem;
            font-family: system-ui, sans-serif;
            box-shadow: 0 4px 20px rgba(0,0,0,0.4);
            backdrop-filter: blur(8px);
            opacity: 0;
            transform: translateX(40px);
            transition: all 0.3s cubic-bezier(0.22, 1, 0.36, 1);
            max-width: 320px;
            pointer-events: auto;
        `;
        toast.textContent = message;

        this.container.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(0)';
        });

        // Animate out and remove
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(40px)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    info(msg)    { this.show(msg, 'info'); }
    success(msg) { this.show(msg, 'success'); }
    warn(msg)    { this.show(msg, 'warn'); }
    error(msg)   { this.show(msg, 'error'); }
}
