# Horizon Client 1.8.9

A modular, browser-based Minecraft client foundation inspired by Badlion Client aesthetics, built for the Eaglercraft ecosystem.

## Current Status

This is a **foundation / starter kit**. It includes:

- Polished Badlion-style main menu
- Core architecture (EventBus, ModuleManager, ConfigManager, KeybindManager, Notifications)
- BaseModule class for easy extension
- Clean project structure ready for 200+ modules

**It is not yet a full playable Eaglercraft client.** Integrating a real 1.8.9 Eaglercraft runtime and implementing 200+ fully working modules requires significant additional work.

## How to Run

1. Open the `HorizonClient` folder.
2. Serve it with any static file server, for example:

```bash
npx serve .
# or
python -m http.server 8080
```

3. Open the URL in a modern browser (Chrome / Edge / Firefox recommended).

You can also simply open `index.html` directly in most browsers, although some features (modules, localStorage) work more reliably when served over HTTP.

## Project Structure

```
HorizonClient/
├── index.html              # Main entry + title screen
├── css/horizon.css         # Main menu & theme styles
├── js/
│   ├── main.js             # Client bootstrap
│   ├── menu/MainMenu.js    # Title screen logic
│   ├── core/               # EventBus, ModuleManager, Config, Keybinds, Notifications
│   ├── gui/                # (ClickGUI & HUD – to be expanded)
│   └── modules/            # Module implementations
│       ├── BaseModule.js
│       ├── combat/
│       ├── movement/
│       ├── render/
│       ├── player/
│       ├── world/
│       ├── client/
│       └── misc/
└── README.md
```

## Adding a New Module

1. Create a file in the appropriate category folder, e.g. `js/modules/combat/KillAura.js`:

```js
import { BaseModule } from '../BaseModule.js';

export class KillAura extends BaseModule {
    constructor(eventBus) {
        super('KillAura', 'COMBAT', 'Automatically attacks nearby players');
        this.eventBus = eventBus;
        this.defaultKey = 82; // R

        this.addSetting('range', 4.2, { min: 1, max: 6, step: 0.1 });
        this.addSetting('aps', 12, { min: 1, max: 20 });
    }

    onEnable() {
        super.onEnable();
        console.log('[KillAura] Enabled');
    }

    onDisable() {
        super.onDisable();
        console.log('[KillAura] Disabled');
    }

    onTick() {
        // Real combat logic would go here
        // (requires access to the Eaglercraft player & entity lists)
    }
}
```

2. Register it inside `ModuleManager.init()`:

```js
import { KillAura } from '../modules/combat/KillAura.js';
// ...
this.register(new KillAura(this.eventBus));
```

## Roadmap Toward a Full Client

- [ ] Integrate actual Eaglercraft 1.8.9 runtime
- [ ] Implement ClickGUI with category columns + search
- [ ] Implement draggable HUD
- [ ] Add 200+ real modules with working logic
- [ ] Config profiles
- [ ] Cosmetics system
- [ ] Multiplayer server list

## License

This foundation is provided for educational and development purposes.  
You are free to modify and extend it.

---

**Horizon Client** – Built for the community.
