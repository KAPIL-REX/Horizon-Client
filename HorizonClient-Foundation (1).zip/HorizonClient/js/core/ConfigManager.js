/**
 * Horizon Client - Configuration Manager
 * Handles saving and loading of module states, keybinds, and settings.
 */

export class ConfigManager {
    constructor() {
        this.storageKey = 'horizon_client_config';
        this.data = {
            modules: {},
            keybinds: {},
            hud: {},
            theme: {
                accent: '#00d4ff',
                backgroundOpacity: 0.85
            },
            version: '1.0.0'
        };
    }

    async load() {
        try {
            const raw = localStorage.getItem(this.storageKey);
            if (raw) {
                const parsed = JSON.parse(raw);
                this.data = { ...this.data, ...parsed };
                console.log('[Config] Loaded configuration from localStorage.');
            } else {
                console.log('[Config] No saved configuration found. Using defaults.');
            }
        } catch (err) {
            console.error('[Config] Failed to load configuration:', err);
        }
        return this.data;
    }

    save() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.data));
            console.log('[Config] Configuration saved.');
            return true;
        } catch (err) {
            console.error('[Config] Failed to save configuration:', err);
            return false;
        }
    }

    getModuleConfig(moduleName) {
        return this.data.modules[moduleName] || {};
    }

    setModuleConfig(moduleName, config) {
        this.data.modules[moduleName] = {
            ...this.data.modules[moduleName],
            ...config
        };
        this.save();
    }

    getTheme() {
        return this.data.theme;
    }

    setTheme(theme) {
        this.data.theme = { ...this.data.theme, ...theme };
        this.save();
    }

    reset() {
        localStorage.removeItem(this.storageKey);
        this.data = {
            modules: {},
            keybinds: {},
            hud: {},
            theme: {
                accent: '#00d4ff',
                backgroundOpacity: 0.85
            },
            version: '1.0.0'
        };
        console.log('[Config] Configuration reset to defaults.');
    }
}
